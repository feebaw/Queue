#include "Ball.h"

Ball::~Ball() //деструктор
{
}
Ball::Ball(float _radius, sf::Color _color, float _xb, float _yb)
{
	ShapeBall.setRadius(_radius);
	ShapeBall.setFillColor(_color);
	ShapeBall.setPosition(_xb, _yb);
	x = _xb;
	y = _yb;
	ShapeBall;
} //инициализирующий конструктор, принимающий параметры радиуса, цвета и начальных координат

//методы
float Ball::getRadius()//возвращает радиус
{
	return radius;
}
void Ball::setRadius(float _radius)//устанавливает новый радиус
{
	radius = _radius;
}
float Ball::getX()//возвращает координату X
{
	return x;
}
float Ball::getY()//возвращает координату Y
{
	return y;
}
sf::CircleShape Ball::getShape()/*возвращает возвращает объект типа sf::CircleShape, 
представляющий визуальное отображение шарика*/
{
	return ShapeBall;
}
void Ball::setX(float _x)/*обновляет координату X и перемещает шарик на новую позицию.*/
{
	x = _x;
	ShapeBall.setPosition(x, y);
}
void Ball::setY(float _y)/*обновляет координату Y и перемещает шарик на новую позицию.*/
{
	y = _y;
	ShapeBall.setPosition(x, y);
}
void Ball::setFillColor(sf::Color _color)/*устанавливает новый цвет для шарика*/
{
	Green = _color;
}

