#include "Bonus.h"

Bonus::Bonus(float _radbonus, sf::Color _color, sf::Vector2f _posbonus)
{
	BonusShape.setFillColor(_color);
	BonusShape.setRadius(_radbonus);
	BonusShape.setPosition(_posbonus);
	posBonus = _posbonus;
	BonusShape;
}//конструктор устанавливает цвет, радиус, позицию бонуса, включая начальную

Bonus::~Bonus()
{
}

sf::CircleShape Bonus::getShapeBonus()
{
	return BonusShape;
}//возвращает объект CircleShape для визуального отображения

float Bonus::getRadius()
{
	return radbonus;
}//возвращает радиус

void Bonus::setRadius(float _radbonus)
{
	radbonus = _radbonus;
}//устанавливает радиус

void Bonus::setFillColor(sf::Color _color)
{
	Yellow = _color;
}//устанавливает цвет

sf::Vector2f Bonus::getPosition()
{
	return posBonus;
}//воозвращает координаты бонуса

void Bonus::setPosition(sf::Vector2f _posbonus)
{
	posBonus.x = _posbonus.x;
	posBonus.y = _posbonus.y;
	BonusShape.setPosition(posBonus);
}//обновляет координаты бонуса и перемещает его на новую позицию

