#pragma once
#include "tools.h"

class Paddle /*инкапсулирует данные и методы подобно классу Ball*/
{
private:
	float xpad;
	float ypad;
	sf::Color Red;
	sf::RectangleShape PaddleShape; /*объект типа sf::RectangleShape, 
	представляющий визуальное отображение платформы.*/
	sf::Vector2f Size; //размеры платформы (ширина и высота)

public:
	Paddle(float _xpad, float _ypad, sf::Color _color, sf::Vector2f _size); //конструктор
	~Paddle();//деструктор
	float getXpad(); //возвращаем координаты платформы
	float getYpad();
	void setXpad(float _x);//устанавливаем новые координаты
	void setYpad(float _y);
	sf::Vector2f getSize();//возвращаем размеры платформы
	void setSize(sf::Vector2f _size);//устанавливаем новые размеры платформы
	sf::RectangleShape getShapePad();//представляем визуальное отображение платформы
	void setFillColor(sf::Color _color);//устанавливаем новый цвет
};

