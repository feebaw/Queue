#include "tools.h"

float fDeltaTime;//хранение значения времени
sf::Time tDeltaTime;//хранение значения времени с последнего обновления

float GetTimeDeltaF()//время с последнего обновления
{
	return fDeltaTime;
}
sf::Time GetTimeDeltaT()//в формате SFML
{
	return tDeltaTime;
}
void RestartClock(sf::Clock& _c)//принимаем ссылку на метод, сбрасываем
{
	tDeltaTime = _c.restart();
	fDeltaTime = tDeltaTime.asSeconds();//отслеживаем время между кадрами
}
bool isCollide( Ball& _shape1, Bricks& _shape2)
{
	return _shape1.getShape().getGlobalBounds().intersects(_shape2.getBricksShape().getGlobalBounds());
}/*Эта функция проверяет, 
пересекаются ли границы шарика (_shape1) и кирпича (_shape2).
Метод getGlobalBounds() возвращает прямоугольник, 
охватывающий форму объекта. 
Если два прямоугольника пересекаются, 
функция возвращает true, 
что указывает на наличие столкновения.*/
bool isCollide(Ball& _shape1, Paddle& _shape2)
{
	return _shape1.getShape().getGlobalBounds().intersects(_shape2.getShapePad().getGlobalBounds());
}/*Эта функция аналогична предыдущей, 
но проверяет столкновение между шариком и платформой*/
bool isCollide(Paddle& _shape1, Bonus& _shape2)
{
	return _shape1.getShapePad().getGlobalBounds().intersects(_shape2.getShapeBonus().getGlobalBounds());
}/*Эта функция проверяет столкновение 
между платформой (_shape1) и бонусом (_shape2)*/