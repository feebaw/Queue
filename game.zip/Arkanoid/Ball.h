#pragma once /*включение заголовка лишь 
один раз для исключения ошибок*/
#include "tools.h" /*включение иного заголовочного файла 
для внесения необходимых библиотек
и других заголовочных файлов*/

class Ball /*объявление класса для инкапсулирования данных и методов, 
связанных с шариком в игре*/
{
private:
	float radius;
	sf::Color Green;
	sf::CircleShape ShapeBall;
	float x; //координаты
	float y;

public:

	Ball(float _radius, sf::Color _color, float _xb, float _yb);/*конструктор
	принимает параметры для инициализации радиуса, цвета и начальных
	координат шарика*/
	~Ball();
	float getRadius();
	void setRadius(float _radius);
	float getX();
	float getY();//получаем значения атрибутов
	sf::CircleShape getShape();
	void setX(float _x);
	void setY(float _y);
	void setFillColor(sf::Color _color);//методы для изменения значений атрибутов
};

