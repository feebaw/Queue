#pragma once
#include "tools.h"

class Bonus //объявление класса, инкапсуляция данных и методов
{
private:
	float radbonus;//радиус шарика бонуса 
	sf::Color Yellow;
	sf::CircleShape BonusShape;//визуальное отображение
	sf::Vector2f posBonus;//координаты
public:
	Bonus(float _radbonus, sf::Color _color, sf::Vector2f _posbonus);//конструктор
	~Bonus();//деструктор
	sf::CircleShape getShapeBonus();//возвращение объекта, визуальное отображение
	float getRadius();//возвращение радиуса
	void setRadius(float _radbonus);//установление нового радиуса
	void setFillColor(sf::Color _color);//установление нового цвета
	sf::Vector2f getPosition();//возвращение координаты
	void setPosition(sf::Vector2f _posbonus);//установление новой позиции

};






